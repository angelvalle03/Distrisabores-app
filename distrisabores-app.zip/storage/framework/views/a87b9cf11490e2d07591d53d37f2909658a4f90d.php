

<?php $__env->startSection('title','Contacto'); ?>
<?php $__env->startSection('content'); ?>

<h1>Contacto</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\distrisabores-app\resources\views/contacto.blade.php ENDPATH**/ ?>