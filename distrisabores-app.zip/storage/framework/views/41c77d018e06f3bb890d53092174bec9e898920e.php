

<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>


<div style="position: relative;">
    <div class="container section">
        <div class="row">
            <div class="col s12 center">
            <h3 class="black-900-italic-titles text-title-index-product"> Productos</h3>
                <div class="line-two"></div>
            </div>
        </div>
        <div class="row section">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col s12 m6 l3">
                        <div class="card">
                            <div class="card-image cont-img-scale-service">
                                <div class="cont-img-text">
                                    <div id="cont-ancla-one">
                                        <img class="img-scale"  width="280" height="280" src="/image/<?php echo e($product->imagen); ?>" loading="lazy">
                                        
                                        
                                        <h5 class="position-text light-300"><?php echo e($product->nombre); ?></h5>
                                        <a class='position-text-a light-300-italic-texts show-category waves-effect' href='#'>Ver detalles</a>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>                            
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\distrisabores-app\resources\views/productos/index.blade.php ENDPATH**/ ?>