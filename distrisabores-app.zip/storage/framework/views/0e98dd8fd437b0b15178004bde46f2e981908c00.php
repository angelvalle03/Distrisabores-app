

<?php $__env->startSection('title',$producto->nombre); ?>
<?php $__env->startSection('content'); ?>

<div class="container section">    
    <div class="row">
        <div class="col s12 center-align">
            <h2 class="flow-text black-900-italic-titles text-title-index-product"><?php echo e($producto->nombre); ?></h2>
            <div class="line"></div>
        </div>
        
    </div>
    <div class="row row-product-detail">
        <div class="col s12 m7 l5 ">
            <div class="card " style="border: none;">
                    <div class="card-image cont-img-product-detail">
                        <img class="materialboxed responsive-img" src="/image/<?php echo e($producto->imagen); ?>" alt="">
                    </div>
            </div>
        </div>
        <div class="col s12 m12 l6 offset-l1">
            <div class="col s12">
                <h4>Detalles</h4><br>
                    <ul>
                        <li>
                            <p><span><i class="fas fa-caret-right orange-text darken-4"></i></span><?php echo e($producto->descripcion); ?></p>
                        </li>
                                            
                    </ul>
            </div>
            <div class="col s12">
                <h5>categoria</h5>
                    <ul>
                        <li><p><?php echo e($producto->categoria->nombre); ?></p></li>
                                        
                    </ul>
            </div>
            <div class="col s12">
                <h5>Precio</h5>
                <ul>
                    <li><p>$<?php echo e($producto->precio); ?> cop</p></li>
                </ul>
            </div>
            <div class="col s12">
                <a href="https://api.whatsapp.com/send?phone=573046760406&amp;text=Quiero mas informacion sobre el producto <?php echo e($producto->nombre); ?>| Distrisabores"
                            target="_blank" class="waves-effect btn-small waves-red orange darken-2">Cotizar</a>
            </div> 
        </div>                    
    </div>
    <div class="row row-product-related">
        <div class="col s12 center-align">
            <h2 class="flow-text black-900-italic-titles text-title-index-product">Productos relacionados</h2>
            <div class="line"></div>  
        </div>
    </div>
    <div class="row products-related">
        <?php $__currentLoopData = $productRelated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col s12 m6 l3">
            <div class="card">
                <div class="card-image cont-img-scale-product">
                    <img class=" img-scale-0" width="250" height="250" src="/image/<?php echo e($related->imagen); ?>" loading="lazy">
                </div>
                <div class="card-content">
                    <span class="light-300"><b><?php echo e($related->nombre); ?><br></b>
                    </span><br>
                    <div class="center">
                        <a class='show-details regular-400-italic waves-effect waves-red' href='#'>Ver detalles</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <div class="col s1"></div>
    </div>
   
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\distrisabores-app\resources\views/productos/show.blade.php ENDPATH**/ ?>