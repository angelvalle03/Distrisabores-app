

<?php $__env->startSection('title',$categorias->nombre); ?>
<?php $__env->startSection('content'); ?>



    <div class="container section">
        <div class="row">
            <div class="col s12 center">
                <h3 class="black-900-italic-titles text-title-index-product"><?php echo e($categorias->nombre); ?></h3>
                <div class="line"></div>
            </div>
        </div>
        <div class="row section">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                <div class="col s12 m6 l3">
                    <div class="card">
                        <div class="card-image cont-img-scale-product">
                            <a href="#!"><img class="acti img-scale-0" width="280" height="280" src="/image/<?php echo e($product->imagen); ?>" loading="lazy"></a>
                        </div>
                        <div class="card-content">
                            <span class="light-300"><b><?php echo e($product->nombre); ?> <br></b>
                                    </span>
                                    
                            <div class="center">                                  
                                <a class='show-details regular-400-italic waves-effect waves-red' href="<?php echo e(route('productos.show', $product->id)); ?>">Ver detalles</a>                      
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\distrisabores-app\resources\views/categorias/show.blade.php ENDPATH**/ ?>