<a href="#arriba" id="botonSubir">
    <i class="fa fa-angle-up"></i>
</a>
<?php /**PATH C:\xampp\htdocs\distrisabores-app\resources\views/layouts/partials/flotante.blade.php ENDPATH**/ ?>