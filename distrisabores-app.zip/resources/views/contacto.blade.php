@extends('layouts.plantilla')

@section('title','Contacto')
@section('content')

<h1>Contacto</h1>

@endsection