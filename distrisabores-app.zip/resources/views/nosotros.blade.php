@extends('layouts.plantilla')

@section('title','Nosotros')
@section('content')

<h1>Nosotros</h1>

@endsection