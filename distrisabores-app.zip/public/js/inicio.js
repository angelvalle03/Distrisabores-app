// document.addEventListener('DOMContentLoaded', function () {
//     var elems = document.querySelectorAll('.slider');
//     var instances = M.Slider.init(elems, {
//         height: 250,
//         interval: 5000,
//         duration: 700,
//         indicators: true
//     });
// });



